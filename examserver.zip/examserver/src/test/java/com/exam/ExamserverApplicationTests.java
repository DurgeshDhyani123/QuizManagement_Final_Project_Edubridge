package com.exam;

import static org.junit.Assert.assertNull;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.Ignore;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.annotation.Order;

import com.exam.model.User;
import com.exam.model.exam.Category;
import com.exam.model.exam.Question;
import com.exam.model.exam.Quiz;
import com.exam.repository.CategoryRepository;
import com.exam.repository.UserRepository;
import com.exam.service.CategoryService;
import com.exam.service.QuestionService;
import com.exam.service.QuizService;

@SpringBootTest
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class ExamserverApplicationTests {
	
	@Autowired
	UserRepository userRepository;
	
	@Autowired
	CategoryService catser;
	@Autowired
	QuizService qz;
	@Autowired
	QuestionService qs;
// user testing 
	@Test
	@Order(1)
	public void getUserTesting()
	{
		User user = this.userRepository.findByUsername("durgesh2295");
		System.out.println(user+"********");
		 assertNotNull(user.getUsername());
	}
	
	//Category Testing
	@Test
	@Order(2)
	public void getCategoryTesting()
	{
		Category cat =  this.catser.getCategory(18L);
		assertNotNull(cat.getTitle());
	}
	@Test
	@Order(3)
	public void getCategoryFalseTesting()
	{
		Category cat =  this.catser.getCategory(18L);
		assertNull( cat.getTitle());
	}
	@Disabled
	@Test
	@Order(4)
	public void getCategoryTitleFalseTesting()
	{
		Category cat =  this.catser.getCategory(18L);
		assertEquals(cat.getTitle(),"Sports");
	}
	@Test
	@Order(5)
	public void getCategoryTitleTesting()
	{
		Category cat =  this.catser.getCategory(11L);
		assertEquals(cat.getTitle(),"sports");
	}
	//Quiz Testing
	@Test
	@Order(6)
	public void getQuizTesting() {
	Quiz q = this.qz.getQuiz(4L);
	assertNotNull(q.getDescription());
	}
   // Question Testing
	@Test
	@Order(7)
	public void getQuestionTesting()
	{
		Question que = qs.getQuestion(5L);
		assertNotNull(que.getContent());
	}
	

}
